# Weekly College Timetable

Your complete weekly college schedule at a glance. Use this as your master reference for planning your week!

---

## 🟢 Monday

**10:00 AM - 12:00 PM** | DAA Lecture

*Instructor:* Laxmi Bawoor

**1:00 PM - 3:00 PM** | EH Lecture

*Instructor:* Vaishali Mishra

---

## 🟣 Tuesday

**9:00 AM - 10:00 AM** | LPCC Lecture

*Instructor:* Manisha Mali

**10:00 AM - 12:00 PM** | AAD Lecture

*Instructor:* Yashwant Dongre

**2:00 PM - 4:00 PM** | CC Lab

*Instructor:* Vikas Kolakar

**4:00 PM - 6:00 PM** | CC Lecture

*Instructor:* Vikas Kolakar

---

## 🔴 Wednesday

**11:00 AM - 12:00 PM** | EH Lecture

*Instructor:* Vaishali Mishra

**1:00 PM - 3:00 PM** | RAM Lecture

*Instructor:* Rahul Divate

**3:00 PM - 4:00 PM** | AAD Lecture

*Instructor:* Yashwant Dongre

**4:00 PM - 5:00 PM** | RAM Tutorial

*Instructor:* Rahul Divate

---

## 🟠 Thursday

**12:00 PM - 2:00 PM** | LPCC Lecture

*Instructor:* Manisha Mali

**3:00 PM - 5:00 PM** | AAD Lab

*Instructor:* Yashwant Dongre

---

## 🔵 Friday

**8:00 AM - 10:00 AM** | DAA Lecture

*Instructor:* Laxmi Bawoor

**10:00 AM - 1:00 PM** | LPCC Lab

*Instructor:* Manisha Mali

**1:00 PM - 3:00 PM** | AAD Lecture

*Instructor:* Yashwant Dongre

---

## 📊 Quick Stats

- **Total class hours per week:** ~30 hours
- **Busiest days:** Tuesday & Thursday (6 hours each)
- **Lightest day:** Monday (4 hours)
- **Free days:** Saturday & Sunday

---

## 📚 Subject Overview

**AAD** - Agile & DevOps

- Tuesday: Lecture (10-12)
- Wednesday: Lecture (3-4)
- Thursday: Lab (3-5)
- Friday: Lecture (1-3)

**CC** - Cloud Computing

- Tuesday: Lab (2-4) + Lecture (4-6)

**DAA** - Design & Analysis of Algorithms

- Monday: Lecture (10-12)
- Friday: Lecture (8-10)

**EH** - Ethical Hacking

- Monday: Lecture (1-3)
- Wednesday: Lecture (11-12)

**LPCC** - Logic Programming & Compiler Construction

- Tuesday: Lecture (9-10)
- Thursday: Lecture (8-10) + Lecture (12-2)
- Friday: Lab (10-1)

**RAM** - Risk Analysis and Management

- Wednesday: Lecture (1-3) + Tutorial (4-5)

---

> 💡 **Tip:** Link this template to your [](https://www.notion.so/54ac6035ddf346c684d84bb54f15804b?pvs=21) database to see all scheduled classes on the calendar!
>